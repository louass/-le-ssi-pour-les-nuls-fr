LE SSI POUR LES NULS FR — PWA

Fichiers à publier ensemble sur un hébergement HTTPS :
- index.html
- manifest.webmanifest
- sw.js
- dossier icons/

INSTALLATION SUR IPHONE :
1. Publier ce dossier sur un hébergement HTTPS.
2. Ouvrir l'adresse du site avec Safari sur l'iPhone.
3. Toucher Partager.
4. Choisir « Sur l'écran d'accueil » / « Ajouter à l'écran d'accueil ».
5. Valider « Ajouter ».

Le site s'ouvrira ensuite depuis son icône comme une application autonome.
Le service worker met en cache les fichiers essentiels pour permettre un usage hors connexion après une première visite réussie.
